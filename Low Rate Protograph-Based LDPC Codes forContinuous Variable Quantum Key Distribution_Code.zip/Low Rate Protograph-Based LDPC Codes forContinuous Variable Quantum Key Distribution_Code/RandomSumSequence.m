function x = RandomSumSequence(CNc, S)
    N = size(CNc,1);
    Group = zeros(N);
    x = zeros(N,1);
    for i = 1:N
        check = 0;
        idx = i;
        idx2 = idx;
        idxtotalprev = 1;
        while check == 0 
            for j = 1:length(idx)
                idx2 = [idx2 find(CNc(:,idx(j)))'];
                idx2 = unique(idx2);
            end
            idxtotal = length(idx2);
            if idxtotal == idxtotalprev
                check = 1;
            end
            idxtotalprev = idxtotal;
            idx = idx2;
        end
        Group(i,1:idxtotal) = idx;
    end
    Group = unique(Group,'rows');
    Nodestotal = zeros(size(Group,1),1);
    for i = 1:size(Group,1)
        Nodestotal(i) = nnz(Group(i,:));
    end
    sumx = 0;
    while sumx < S
        check = 0;
        while check == 0
            idx = randi(size(Group,1));
            if sumx + Nodestotal(idx) <= S
                idx2 = Group(idx,:);
                idx2 = idx2(idx2 > 0);
                x(idx2) = x(idx2) + 1;
                sumx = sumx + Nodestotal(idx);
                check = 1;
            end
        end
    end
end