function [threshold, I_APP] = PEXITcpp_TBP(CN,CNG,VNG, iterations, ebno_min, ebno_max, Gauss_Hermite, LUT,GH)
    VN_punctured = [];
    CN(CNG == 0,:) = [];
    CN(:,VNG == 0) = [];
    CNG(CNG == 0) = [];
    VNG(VNG == 0) = [];
    R = (sum(VNG)-sum(CNG))/sum(VNG);
    parameters = [size(CN,1) size(CN,2) iterations ebno_min ebno_max R];
    CN = reshape(CN',size(CN,1)*size(CN,2),1);
    if Gauss_Hermite == 0
        [threshold,I_APP] = PEXITmex_TBP(CN,VN_punctured-1,parameters,CNG,VNG);
    else
        [threshold,I_APP] = PEXITmex_GH_TBP(CN,VN_punctured-1,parameters,CNG,VNG,LUT,GH.xi,GH.alpha);
    end
end