%% A function that can turn a given protomatrix into a type description 
% B: The protomatrix
% VN_punctured: The indices of any punctured variable nodes
function [TD,CNgroup,VNgroup] = BtoTypeDescription(B,VN_punctured)
%% Determine CN types
    CNdist = zeros(size(B));
    for i = 1:size(B,1)
        temp = B(i,:);
        temp = temp(temp > 0);
        CNdist(i,1:length(temp)) = temp;
    end
    CNdegrees_unique = unique(CNdist,'rows');
    for i = 1:size(CNdist,1)
        for j = 1:length(CNdegrees_unique)
            if nnz(CNdist(i,:) == CNdegrees_unique(j,:)) == size(B,2)
                CNtype(i) = j;
                break;
            end
        end
    end

%% Determine types of Vns
    VNneighbourhood = zeros(size(B,2),length(CNdegrees_unique));
    for i = 1:size(B,1)
        for j = 1:size(B,2)
            VNneighbourhood(j,CNtype(i)) = VNneighbourhood(j,CNtype(i)) + B(i,j);
        end
    end

    VNneighbourhood_unique = unique(VNneighbourhood,'rows');
    VN_punctured2 = zeros(length(CNtype),1);
    for i = 1:size(B,2)
        for j = 1:size(VNneighbourhood_unique,1)
            if nnz(VNneighbourhood(i,:) == VNneighbourhood_unique(j,:)) == size(VNneighbourhood,2)
                VNtype(i) = j;
                if ismember(i,VN_punctured)
                    VN_punctured2 = [VN_punctured2 j];
                end
                break;
            end
        end
    end
%% Split Cns up into groups with the same neighbourhood
    CNneighbourhood = zeros(size(B,1),size(VNneighbourhood_unique,1));
    CNneighbourhood2 = zeros(size(B,1),size(VNneighbourhood_unique,1));
    for i = 1:size(B,2)
        for j = 1:size(B,1)
            if CNneighbourhood(j,VNtype(i)) == 0
                CNneighbourhood(j,VNtype(i)) = CNneighbourhood(j,VNtype(i)) + B(j,i);
            end
            CNneighbourhood2(j,VNtype(i)) = CNneighbourhood2(j,VNtype(i)) + B(j,i);
        end
    end
    Edge_Occurence = sum(CNneighbourhood2,1)./sum(CNneighbourhood,1);
    CNneighbourhood_unique = unique(CNneighbourhood,'rows');
    CNgroup = zeros(size(CNneighbourhood_unique,1),1);
    for i = 1:size(B,1)
        for j = 1:size(CNneighbourhood_unique,1)
            if nnz(CNneighbourhood(i,:) == CNneighbourhood_unique(j,:)) == size(CNneighbourhood,2)
                CNgroup(j) = CNgroup(j) + 1;
                break;
            end
        end
    end
    CNneighbourhood_unique = repelem(CNneighbourhood_unique,ones(size(CNneighbourhood_unique,1),1),Edge_Occurence);

%% Determine the amount of edges connected to each VN
    VNgroup = zeros(size(CNneighbourhood,2),1);
    VNgroup(size(VNneighbourhood_unique,1)+1:end) = 1;
    for i = 1:size(VNtype,2)
        VNgroup(VNtype(i)) = VNgroup(VNtype(i)) + 1/Edge_Occurence(VNtype(i));
    end
    VNgroup = repelem(VNgroup,Edge_Occurence);
    TD = CNneighbourhood_unique;
end