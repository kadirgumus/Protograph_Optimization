%% A function for optimizing type based protographs
% Type_Description: The input type description
% m : the total amount of check nodes, this also determines the
% rate of the code
% k: The amount of fixed check nodes types 
% l: The amount of fixed variable nodes types
% Gauss_Hermite: 0 if you don;t want to use GH approximation, 1 if you do
% For the paper "Low Rate Protograph-Based LDPC Codes forContinuous
% Variable Quantum Key Distribution" k =1, l = 2 for the normal TBP, and k
% = 4 and l = 8 for the expanded TBP
% For the optimization, using the Gauss-Hermite approximation is not
% necessary, the other approximation works and is much faster. However, for
% low rate codes, the threshold given by the PEXIT will be very much higher
% when compared to the actual threshold. So use the Gauss-Hermite
% approximation for determining the actual threshold, 
% but the non Gauss-Hermite approximation during the optimization.
function [B_out,CNgroup,VNgroup,threshold] = Differenital_Evolution_TBP(Type_Description, m, k, l, Gauss_Hermite)
%% Define parameters
    parameters.p_c = 0.88;
    parameters.S = 100;
    parameters.G = 1000;

%% Determine which optimizable CNs are connected to which optimizable VNs
    VNo = ones(1,size(Type_Description,2));
    VNo(1:l) = 0;
    CNc = zeros(size(Type_Description,1)-k);
    for i = k+1:size(Type_Description,1)
        temp = Type_Description(i,:).*VNo;
        idx = find(temp);
        VND1{i-k} = idx;
    end
    for i = l+1:size(Type_Description,2)
        idx = find(Type_Description(:,i));
            for j = 1:length(idx)
                for c = 1:length(idx)
                    CNc(idx(j)-k,idx(c)-k) = 1;
                end
            end
    end
%% The optimization
    [CNgroup, threshold] = Differential_Evolution(Type_Description,m, VND1,CNc,k,parameters, Gauss_Hermite);
    VNgroup = ones(size(Type_Description,2),1);
    for i = 1:length(VND1)
        VNgroup(VND1{i}) = CNgroup(i+k);
    end
    B_out = getB(Type_Description,CNgroup,VNgroup);
end

%% A function that creates a protograph based on the distribution of CNs
function B_out = getB(TD,CNG,VNG)
    M = length(CNG);
    N = length(VNG);
    B_out = zeros(sum(CNG),sum(VNG));
    idxN = 1;
    for i = 1:N
        idxM = 1;
        for j = 1:M
            temp = zeros(CNG(j),VNG(i));
            temp2 = [TD(j,i) zeros(1,VNG(i)-1)];
            for k = 1:CNG(j)
                temp(k,:) = circshift(temp2,(k-1) + idxM);
            end
            B_out(idxM:idxM+CNG(j)-1,idxN:idxN+VNG(i)-1) = temp;
            idxM = idxM+CNG(j);
        end
        idxN = idxN + VNG(i);
    end
end

%% The loss function
function threshold = thresholdB(TD,CNG,VND1,k,Gauss_Hermite,LUT,GH)
    VNG= ones(size(TD,2),1);
    for i = 1:length(VND1)
        VNG(VND1{i}) = CNG(i+k);
    end
    threshold = PEXITcpp_TBP(TD,CNG,VNG,1000,-2,40,Gauss_Hermite,LUT,GH);
end

%% Differential Evolution
function [CNG_out, threshold] = Differential_Evolution(TD, m,VND1, CNc, k,parameters, Gauss_Hermite)
    %Initialization
    LUT = load('LUT.mat');
    LUT = LUT.LUT;
    J = '100'; 
    GH = load(['GaussHermitePoints/GaussHermite_J_',J,'.mat']);
    p_c = parameters.p_c;
    S = parameters.S;
    G = parameters.G;
    N = size(TD,1);
    
    CNG_current = zeros(N,S);
    CNG_next = zeros(N,S);
    CNGidx = k+1:N;
    for i = 1:S
        I = 0;
        while(I == 0)
              CNG_current(1:k,i) = 1;
              CNG_current(CNGidx,i) = RandomSumSequence(CNc,m-k);
              I = Prespecified_Condition(CNG_current(:,i),m,CNc,k);
        end
        delta_CNG(i) = thresholdB(TD,CNG_current(:,i),VND1,k,Gauss_Hermite,LUT,GH);
    end
    for i = 1:G
        for j = 1:S
            %Mutation
            idx = randperm(S,3);
            M = CNG_current(:,idx(1)) + 0.5*(CNG_current(:,idx(2)) - CNG_current(:,idx(3)));
            M(M < 0) = 0;
            idx4 = randperm(length(M),floor(length(M)/2));
            M(idx4) = M(idx4) + 0.5;
            %Crossover
            rand_prob = rand(N,1);
            rand_prob = (rand_prob > p_c);
            CNGnew = floor(M);
            CNG_temp = CNG_current(:,j);
            CNGnew(rand_prob == 1) = CNG_temp(rand_prob == 1);
            %Selection
            I = Prespecified_Condition(CNGnew,m,CNc,k);
            if CNGnew == CNG_temp
                I = 0;
            end
            if(I == 1)
                delta_N = thresholdB(TD,CNGnew,VND1,k,Gauss_Hermite,LUT,GH);
                if(delta_N < delta_CNG(j))
                    CNG_next(:,j) = CNGnew;
                    delta_CNG(j) = delta_N;
                else
                    CNG_next(:,j) = CNG_temp; 
                end
            else
                CNG_next(:,j) = CNG_temp; 
            end
        end
        CNG_current = CNG_next;
        if length(unique(delta_CNG)) == 1
            break;
        end
    end
    [~,idx] = min(delta_CNG);
    CNG_out = CNG_current(:,idx);
    threshold = thresholdB(TD,CNGnew,VND1,k,1,LUT,GH);
end
%% Prespecified condition
% The function to determine whether a matrix satisfies a prespecified
% condition. Needs to be changed manually to fit the desired conditions.
function I = Prespecified_Condition(CNG,N,CNc,k)
    if sum(CNG) ~= N
        I = 0;
        return;
    end
    for i = 1:size(CNc,1)
        idx = find(CNc(i,:));
        if length(unique(CNG(idx + k))) > 1
            I = 0;
            return;
        end
    end
    I = 1;
end









